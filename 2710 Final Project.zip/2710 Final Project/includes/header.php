<table class="nav">
  <tr>
    <td><a href="../index.php" id="logo">ComforTABLE</a></td>
  </tr>
</table>
