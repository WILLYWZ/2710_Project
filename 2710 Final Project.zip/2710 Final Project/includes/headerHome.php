<table class="nav">
  <tr>
    <td><a href="../pages/salesHome.php" id="logo">ComforTABLE</a></td>
  </tr>
</table>
