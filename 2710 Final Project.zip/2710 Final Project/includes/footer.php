<footer>
  <p>INFSCI 2710 Database Management Project</p>
</footer>
